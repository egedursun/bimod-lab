"""Small NumPy datasets for debugging/testing."""

from keras.src.datasets import boston_housing
from keras.src.datasets import california_housing
from keras.src.datasets import cifar10
from keras.src.datasets import cifar100
from keras.src.datasets import fashion_mnist
from keras.src.datasets import imdb
from keras.src.datasets import mnist
from keras.src.datasets import reuters
